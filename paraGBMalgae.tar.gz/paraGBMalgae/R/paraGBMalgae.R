#' Empty function 
#' 
#' @param x null
#' @return a vector
#' @export

kk <- function(x){load("para1.RData"); print(head(para1))}